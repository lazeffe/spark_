create view EMP_VIEW20 as
  select empno, ename, deptno, mgr
from emp_copy
where deptno = 20
/

