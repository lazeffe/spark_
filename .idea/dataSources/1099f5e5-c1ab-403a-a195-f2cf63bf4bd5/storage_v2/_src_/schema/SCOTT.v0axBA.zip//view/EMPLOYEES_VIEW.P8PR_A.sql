create view EMPLOYEES_VIEW as
  select empno, ename, deptno from employees
where deptno = 30
/

