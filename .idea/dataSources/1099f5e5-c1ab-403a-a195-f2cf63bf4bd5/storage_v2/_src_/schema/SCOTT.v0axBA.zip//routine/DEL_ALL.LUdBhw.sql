create procedure DEL_ALL
is
begin
    delete from emp01;
end;
/

