create view VIEW_SAL as
  select deptno, sum(sal) as "총 급여", avg(sal) "평균 급여"
from emp_copy
group by deptno
/

