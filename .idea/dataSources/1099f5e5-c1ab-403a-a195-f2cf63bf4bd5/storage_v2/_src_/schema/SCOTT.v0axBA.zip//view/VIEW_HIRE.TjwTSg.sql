create view VIEW_HIRE as
  select empno, ename, hiredate
from emp
order by hiredate
/

