create view EMP_VIEW30 as
  select empno, ename, sal, comm, deptno
from emp_copy
where deptno = 30
/

