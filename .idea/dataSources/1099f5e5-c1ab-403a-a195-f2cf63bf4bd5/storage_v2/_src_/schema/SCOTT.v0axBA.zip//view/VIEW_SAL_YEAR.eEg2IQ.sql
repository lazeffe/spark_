create view VIEW_SAL_YEAR as
  select ename, sal*12 "연봉"
from emp_copy
/

