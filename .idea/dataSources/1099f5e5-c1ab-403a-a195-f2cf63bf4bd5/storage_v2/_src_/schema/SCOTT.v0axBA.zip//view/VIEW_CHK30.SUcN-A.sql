create view VIEW_CHK30 as
  select empno, ename, sal, comm, deptno
from emp_copy
where deptno = 30 with check option
/

