create view EMP_VIEW_COPY as
  select empno, ename, sal, deptno
from emp_copy
/

