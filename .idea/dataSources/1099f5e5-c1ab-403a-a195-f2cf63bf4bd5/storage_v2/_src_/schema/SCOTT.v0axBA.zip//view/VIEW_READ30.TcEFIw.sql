create view VIEW_READ30 as
  select empno, ename, sal, comm, deptno
from emp_copy03
where deptno = 30 with read only
/

